# TP2 - Grafos (Algoritmos e Classificação de Dados) - Parte 1

Primeira parte do TP2:
- as classes de grafo do modelo UML da disciplina (`Graph.pdf`);
- a leitura dos arquivos `.gr` do GTgraph fornecidos pelo professor;
- as buscas em largura e em profundidade;
- um menu que mostra o grafo de entrada, o algoritmo executado, o resultado e o tempo de execução.

## Como rodar

Requisito: Java 17 ou mais novo. Rodar na pasta do projeto (onde fica a pasta `grafos/`).

```
javac -d bin src/*.java
java -cp bin Main
```

No VS Code: abrir a pasta do projeto (File > Open Folder) e rodar `src/Main.java`.

## Menu

1. Mostra os grafos de exemplo como lista de adjacência e como matriz.
2. Busca em largura no grafo do Cormen (origem `s`), em LA e em MA, com o tempo de cada uma.
3. Busca em profundidade no dígrafo do Cormen, em LA e em MA, com os tempos de descoberta e término.
4. Lista os 15 grafos do professor (pasta `grafos/`), lê o escolhido nas duas representações
   e roda a BFS e a DFS, mostrando os tempos.

Os tempos são medidos com `System.nanoTime()`, só em volta do algoritmo, depois de 5
execuções de aquecimento da JVM, que são descartadas.

## Classes

Modelo UML (`Graph.pdf`):

| Classe | O que faz |
|---|---|
| `GraphType` | `DIRECTED` ou `UNDIRECTED` |
| `IGraph` | Interface: `type`, `vertices`, `edges`, `addEdge`, `getEdge`, `adj`, `numVertices`, `numEdges` |
| `Vertex` | Vértice: `id` e `label` |
| `Edge` | Aresta: vértices `u` e `v` e peso (`double`, padrão 1) |
| `AdjListGraph` | Lista de adjacência (LA): memória O(V + E), `adj(u)` em O(grau) |
| `AdjMatrixGraph` | Matriz de adjacência (MA) de `Edge`: memória O(V²), `getEdge` em O(1), `adj(u)` em O(V) |

Os construtores lançam `IllegalArgumentException` se `numVertices < 0`, e `validateVertex`
lança `IndexOutOfBoundsException` para vértice fora do intervalo, como no modelo.

Demais classes:

| Classe | O que faz |
|---|---|
| `GraphReader` | Lê os arquivos `.gr` (`p sp V E` e `a u v w`) em LA ou MA |
| `GraphUtils` | Densidade, resumo, impressão e o "outro extremo" de uma aresta |
| `BuscaEmLargura` | BFS: distância, predecessor, caminho e ordem de descoberta |
| `BuscaEmProfundidade` | DFS: tempos d/f, predecessor, ordem de término e detecção de ciclo |
| `Exemplos` | Grafos pequenos (do Cormen e do enunciado) para conferir os algoritmos à mão |
| `Main` | Menu |

Os algoritmos usam só os métodos de `IGraph`, então funcionam com as duas representações.

## Observações sobre os arquivos do professor

- Nos arquivos os vértices vão de 1 a |V|; no programa, de 0 a |V|-1.
- **Arcos repetidos.** O GTgraph sorteia os arcos com reposição, então o mesmo par (u, v)
  aparece várias vezes. A matriz só comporta uma aresta por par; para LA e MA guardarem
  exatamente o mesmo grafo, o leitor junta os repetidos e fica com o menor peso (o único que
  importa para caminhos mínimos). Por isso o número de arestas e a densidade reais ficam
  abaixo dos nominais:

| Arquivo | Arcos no arquivo | Arestas distintas | Densidade nominal | Densidade real |
|---|---:|---:|---:|---:|
| sample100-1980 | 1.980 | 1.773 | 0,2 | 0,179 |
| sample100-3960 | 3.960 | 3.266 | 0,4 | 0,330 |
| sample100-5940 | 5.940 | 4.438 | 0,6 | 0,448 |
| sample100-7920 | 7.920 | 5.391 | 0,8 | 0,545 |
| sample100-9900 | 9.900 | 6.215 | 1,0 | 0,628 |
| sample200-7960 | 7.960 | 7.205 | 0,2 | 0,181 |
| sample200-15920 | 15.920 | 13.072 | 0,4 | 0,328 |
| sample200-23880 | 23.880 | 17.929 | 0,6 | 0,450 |
| sample200-31840 | 31.840 | 21.907 | 0,8 | 0,550 |
| sample200-39800 | 39.800 | 25.167 | 1,0 | 0,632 |
| sample500-49900 | 49.900 | 45.108 | 0,2 | 0,181 |
| sample500-99800 | 99.800 | 82.141 | 0,4 | 0,329 |
| sample500-149700 | 149.700 | 112.525 | 0,6 | 0,451 |
| sample500-199600 | 199.600 | 137.330 | 0,8 | 0,550 |
| sample500-249500 | 249.500 | 157.800 | 1,0 | 0,632 |

- Os arquivos têm arestas com peso 0; na matriz, "sem aresta" é `null`, e não um peso especial.
- Densidade: D = |E| / (|V|(|V|-1)) para dígrafos, como no enunciado; no grafo não dirigido
  cada aresta conta nos dois sentidos.

## Próximas partes

Ordenação topológica, Kruskal, Prim, Bellman-Ford, Dijkstra, Floyd-Warshall e
Ford-Fulkerson, e o experimento LA × MA com Bellman-Ford e Dijkstra nos 15 grafos.
