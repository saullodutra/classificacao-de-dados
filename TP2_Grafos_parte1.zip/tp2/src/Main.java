import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.function.Supplier;

/**
 * Menu do TP2 (primeira parte): representações de grafo do modelo UML, leitura dos
 * arquivos .gr do professor e buscas em largura e em profundidade, com o tempo de execução.
 *
 * Compilar:  javac -d bin src/*.java
 * Executar:  java -cp bin Main      (rodar na pasta do projeto, onde fica a pasta grafos/)
 */
public class Main {

    private static final GraphReader.Representacao LA = GraphReader.Representacao.LA;
    private static final GraphReader.Representacao MA = GraphReader.Representacao.MA;
    private static final GraphReader.Representacao[] AMBAS = {LA, MA};

    /** Execuções descartadas antes de medir, para o JIT da JVM otimizar o código. */
    private static final int AQUECIMENTO = 5;

    private static final String PASTA_GRAFOS = "grafos";

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println();
            System.out.println("=========== TP2 - Grafos (parte 1) ===========");
            System.out.println("1. Mostrar os grafos de exemplo (LA e MA)");
            System.out.println("2. Busca em largura (BFS) no grafo de exemplo");
            System.out.println("3. Busca em profundidade (DFS) no digrafo de exemplo");
            System.out.println("4. Ler um grafo do professor (.gr) e rodar BFS e DFS (LA e MA)");
            System.out.println("0. Sair");
            System.out.print("Opcao: ");
            if (!in.hasNextLine()) {
                return;
            }
            switch (in.nextLine().trim()) {
                case "1" -> mostrarExemplos();
                case "2" -> demonstrarBfs();
                case "3" -> demonstrarDfs();
                case "4" -> rodarArquivo(in);
                case "0" -> {
                    return;
                }
                default -> System.out.println("Opcao invalida.");
            }
        }
    }

    private static void mostrarExemplos() {
        titulo("Grafo nao dirigido da BFS (Cormen)");
        System.out.print(Exemplos.grafoBusca(LA));
        System.out.println("Mesmo grafo como matriz:");
        System.out.print(((AdjMatrixGraph) Exemplos.grafoBusca(MA)).imprimirMatriz());

        titulo("Digrafo da DFS (Cormen)");
        System.out.print(Exemplos.digrafoProfundidade(LA));

        titulo("Digrafo ponderado (sample.gr do enunciado)");
        System.out.print(Exemplos.digrafoPonderado(LA));
        System.out.println("Mesmo digrafo como matriz (pesos):");
        System.out.print(((AdjMatrixGraph) Exemplos.digrafoPonderado(MA)).imprimirMatriz());
    }

    private static void demonstrarBfs() {
        for (GraphReader.Representacao rep : AMBAS) {
            IGraph g = Exemplos.grafoBusca(rep);
            titulo("Algoritmo: Busca em Largura | " + GraphUtils.nomeRepresentacao(g));
            System.out.println("Grafo de entrada:");
            System.out.print(g);
            long ns = medir(() -> new BuscaEmLargura(g, 1));
            System.out.print(new BuscaEmLargura(g, 1).relatorio());
            imprimirTempo(ns);
        }
    }

    private static void demonstrarDfs() {
        for (GraphReader.Representacao rep : AMBAS) {
            IGraph g = Exemplos.digrafoProfundidade(rep);
            titulo("Algoritmo: Busca em Profundidade | " + GraphUtils.nomeRepresentacao(g));
            System.out.println("Grafo de entrada:");
            System.out.print(g);
            long ns = medir(() -> new BuscaEmProfundidade(g));
            System.out.print(new BuscaEmProfundidade(g).relatorio());
            imprimirTempo(ns);
        }
    }

    private static void rodarArquivo(Scanner in) {
        String caminho = escolherArquivo(in);
        if (caminho == null) {
            return;
        }
        for (GraphReader.Representacao rep : AMBAS) {
            GraphReader.Leitura leitura;
            try {
                leitura = GraphReader.ler(caminho, rep);
            } catch (IOException | RuntimeException e) {
                System.out.println("Erro ao ler o arquivo: " + e.getMessage());
                return;
            }
            IGraph g = leitura.grafo();
            titulo("Arquivo " + caminho + " | " + GraphUtils.nomeRepresentacao(g));
            System.out.printf("Arcos no arquivo: %d | pares repetidos juntados (menor peso): %d%n",
                    leitura.arcosNoArquivo(), leitura.paresRepetidos());
            System.out.println("(vertices de 0 a |V|-1: o vertice 1 do arquivo e o 0 aqui)");
            System.out.print(GraphUtils.imprimir(g, 8));

            long nsBfs = medir(() -> new BuscaEmLargura(g, 0));
            BuscaEmLargura bfs = new BuscaEmLargura(g, 0);
            System.out.println("-- Busca em Largura a partir do vertice 0: " + bfs.alcancados()
                    + " vertices alcancados, maior distancia = "
                    + Arrays.stream(bfs.getDist()).max().orElse(0));
            imprimirTempo(nsBfs);

            long nsDfs = medir(() -> new BuscaEmProfundidade(g));
            BuscaEmProfundidade dfs = new BuscaEmProfundidade(g);
            System.out.println("-- Busca em Profundidade: tem ciclo = " + (dfs.temCiclo() ? "sim" : "nao"));
            imprimirTempo(nsDfs);
        }
    }

    /** Lista os .gr da pasta grafos/ e devolve o escolhido (ou um caminho digitado). */
    private static String escolherArquivo(Scanner in) {
        File[] arquivos = new File(PASTA_GRAFOS).listFiles((dir, nome) -> nome.endsWith(".gr"));
        if (arquivos != null && arquivos.length > 0) {
            Arrays.sort(arquivos, (a, b) -> Long.compare(tamanho(a), tamanho(b)));
            System.out.println("Grafos em " + PASTA_GRAFOS + "/:");
            for (int i = 0; i < arquivos.length; i++) {
                System.out.printf("%3d. %s%n", i + 1, arquivos[i].getName());
            }
        } else {
            System.out.println("(pasta " + PASTA_GRAFOS + "/ nao encontrada; digite o caminho do arquivo)");
        }
        System.out.print("Numero ou caminho do arquivo: ");
        String resp = in.hasNextLine() ? in.nextLine().trim() : "";
        if (resp.isEmpty()) {
            return null;
        }
        if (arquivos != null && resp.matches("\\d+")) {
            int i = Integer.parseInt(resp) - 1;
            if (i < 0 || i >= arquivos.length) {
                System.out.println("Numero invalido.");
                return null;
            }
            return arquivos[i].getPath();
        }
        return resp;
    }

    /** Ordena os arquivos do GTgraph por |V| e depois por |E| (sample100-1980 antes de sample100-3960). */
    private static long tamanho(File f) {
        String[] p = f.getName().replaceAll("[^0-9-]", "").split("-");
        try {
            return Long.parseLong(p[0]) * 10_000_000L + Long.parseLong(p[1]);
        } catch (RuntimeException e) {
            return Long.MAX_VALUE;
        }
    }

    /** Roda o algoritmo AQUECIMENTO vezes sem medir e depois mede uma execução. */
    private static long medir(Supplier<Object> algoritmo) {
        for (int i = 0; i < AQUECIMENTO; i++) {
            algoritmo.get();
        }
        long inicio = System.nanoTime();
        algoritmo.get();
        return System.nanoTime() - inicio;
    }

    private static void imprimirTempo(long ns) {
        System.out.printf("Tempo de execucao: %.4f ms (%d ns)%n", ns / 1e6, ns);
    }

    private static void titulo(String t) {
        System.out.println();
        System.out.println("--- " + t + " ---");
    }
}
